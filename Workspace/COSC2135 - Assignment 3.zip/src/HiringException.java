
public class HiringException extends Exception {
    public HiringException(String errorMessage) {
        super(errorMessage);
    }
}
